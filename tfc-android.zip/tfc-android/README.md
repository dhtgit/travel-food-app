# Travel Food Companion — Android (TWA) Setup Guide

This is a **Trusted Web Activity (TWA)** Android project. It wraps your hosted PWA
(`index.html` on GitHub Pages) into a Play Store–publishable Android app — no browser
chrome, full-screen, indistinguishable from a native app.

---

## Prerequisites

| Tool | Download |
|------|----------|
| Android Studio (Hedgehog or later) | https://developer.android.com/studio |
| JDK 17 | bundled with Android Studio |
| Google Play Developer account ($25 one-time) | https://play.google.com/console |

---

## Step 1 — Customise the package name

Replace every occurrence of `com.yourname.travelfoodcompanion` with your own reverse-domain
package name (e.g. `com.huytran.travelfoodcompanion`).

Files to update:
- `app/build.gradle` → `applicationId` and `namespace`
- `app/src/main/AndroidManifest.xml` → `package` attribute, `android:authorities`, `file_provider`

---

## Step 2 — Set your hosted URL

In `app/src/main/AndroidManifest.xml`, replace **both** occurrences of
`YOUR_GITHUB_USERNAME` with your actual GitHub username:

```xml
<meta-data
    android:name="android.support.customtabs.trusted.DEFAULT_URL"
    android:value="https://YOUR_GITHUB_USERNAME.github.io/travel-food-app/" />

<data android:scheme="https"
      android:host="YOUR_GITHUB_USERNAME.github.io"
      android:pathPrefix="/travel-food-app/" />
```

---

## Step 3 — Generate a release keystore

Open a terminal and run:

```bash
keytool -genkey -v \
  -keystore tfc-release.keystore \
  -alias tfc-key \
  -keyalg RSA -keysize 2048 \
  -validity 10000
```

Move `tfc-release.keystore` into a `keystore/` folder next to the `app/` folder.

Then uncomment the `signingConfigs` block in `app/build.gradle` and fill in your passwords.

**⚠️ Keep your keystore safe — you can NEVER change it after publishing to Play Store.**

---

## Step 4 — Get your SHA-256 fingerprint

After creating the keystore, run:

```bash
keytool -list -v \
  -keystore keystore/tfc-release.keystore \
  -alias tfc-key
```

Copy the **SHA256 fingerprint** (format: `AB:CD:EF:...`).

---

## Step 5 — Add assetlinks.json to your website

1. Open `.well-known/assetlinks.json` (in this project folder)
2. Replace `REPLACE_WITH_YOUR_SHA256_FINGERPRINT` with the fingerprint from Step 4
3. Replace `com.yourname.travelfoodcompanion` with your actual package name
4. Host this file at: `https://YOUR_GITHUB_USERNAME.github.io/.well-known/assetlinks.json`

   To do this on GitHub Pages, create a `.well-known/` folder in your repo root and commit
   the file. GitHub Pages will serve it automatically.

5. Verify it works: https://developers.google.com/digital-asset-links/tools/generator

---

## Step 6 — Build the release APK / AAB

1. Open this project in Android Studio (`File → Open → select the tfc-android folder`)
2. Wait for Gradle sync to complete
3. Go to **Build → Generate Signed Bundle / APK**
4. Choose **Android App Bundle (.aab)** — Play Store requires AAB
5. Select your keystore and fill in the passwords
6. Choose **release** build variant
7. Click **Finish** — the `.aab` file is generated in `app/release/`

---

## Step 7 — Publish to Google Play Store

1. Go to https://play.google.com/console
2. Create a new app → fill in title, description, category (Travel & Local)
3. Upload the `.aab` file under **Production → Releases**
4. Fill in the store listing:
   - **App name**: Your Travel Food Companion
   - **Short description**: Find the best local food wherever you travel
   - **Full description**: Discover authentic local restaurants and hidden food gems in
     100+ cities across Vietnam and beyond. Powered by Google Maps with a smart learning
     system that remembers your preferences.
   - **Category**: Travel & Local
5. Add screenshots (take them on a phone or Android emulator)
6. Submit for review — Google reviews in 1–3 days

---

## File structure

```
tfc-android/
├── app/
│   ├── build.gradle              ← package name, version, signing
│   └── src/main/
│       ├── AndroidManifest.xml   ← TWA URL, deep links
│       └── res/
│           ├── drawable/
│           │   └── splash_icon.png
│           ├── mipmap-*/         ← launcher icons (all densities)
│           ├── values/
│           │   ├── strings.xml
│           │   ├── colors.xml
│           │   ├── styles.xml
│           │   └── bools.xml
│           └── xml/
│               └── file_paths.xml
├── gradle/wrapper/
│   └── gradle-wrapper.properties
├── .well-known/
│   └── assetlinks.json           ← host at YOUR_DOMAIN/.well-known/
├── build.gradle
├── settings.gradle
├── gradle.properties
└── README.md
```

---

## Updating the app

Since this is a TWA, **you never need to republish to Play Store** just to update content
or fix bugs — just push changes to GitHub Pages and all users get the update instantly.

Only republish to Play Store if you change:
- The app name or icons
- The `AndroidManifest.xml`
- The `build.gradle` version code/name

---

## Testing before publishing

Install on a real device without Play Store:
```bash
# Build debug APK
./gradlew assembleDebug

# Install via ADB (phone must have USB debugging on)
adb install app/build/outputs/apk/debug/app-debug.apk
```

Or use Android Studio's **Run** button with an emulator / physical device.
